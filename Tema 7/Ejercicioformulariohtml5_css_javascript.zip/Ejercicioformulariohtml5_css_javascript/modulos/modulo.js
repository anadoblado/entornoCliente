import {validacion} from "../js/validaciones_formulario.js";

document.addEventListener("DOMContentLoaded",e=>{
    validacion();
});